package com.nivi;

import com.nivi.service.UserService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
/**
 * @Author: pxp167
 * @Date: 9/27/2018
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
@ActiveProfiles(profiles = "dev")
@ContextConfiguration(classes = {Config.class})
@EnableAutoConfiguration
public class DataBaseTest {

  @Autowired
  private UserService userService;

  //@Test
  public  void testConnection(){
    userService.createUser();
  }

  @Test
  public void testFindAll(){
    userService.getUsers();
  }

}
