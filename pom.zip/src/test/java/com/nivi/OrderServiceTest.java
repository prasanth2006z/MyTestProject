package com.nivi;

import com.nivi.pojo.Order;
import com.nivi.pojo.Product;
import com.nivi.pojo.User;
import com.nivi.service.OrderService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.ArrayList;
import java.util.List;

/**
 * @Author: pxp167
 * @Date: 9/28/2018
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
@ActiveProfiles(profiles = "dev")
@ContextConfiguration(classes = {Config.class})
@EnableAutoConfiguration
public class OrderServiceTest {
  @Autowired
  private OrderService orderService;


  @Test
  public void testSave(){
    Order order =new Order();
    order.setOrderStatus("success");
    User user=new User();
    user.setUserName("Prasanth");
    order.setUser(user);

    Product product =new Product();
    product.setProductName("Water");
    product.setPriceperUnit(20);
    List<Product> products=new ArrayList<>();
    products.add(product);

    order.setProducts(products);


    orderService.save(order);



  }
}
