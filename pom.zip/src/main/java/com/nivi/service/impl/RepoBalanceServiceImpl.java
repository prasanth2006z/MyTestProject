package com.nivi.service.impl;

import com.nivi.constants.Constant;
import com.nivi.service.RepoBalanceService;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

/**
 * @Author: pxp167
 * @Date: 9/26/2018
 *
 */
@Component
public class RepoBalanceServiceImpl implements RepoBalanceService {

  @Override public int getAvailableBalance(long itemId) {
    return Constant.MINIMUM_WATER_REPO_BALANCE;
  }

  synchronized
  @Override public void updateRepoBalance(long itemId, int quantity) {
    System.out.println(itemId);
  }
}
