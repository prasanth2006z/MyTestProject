package com.nivi.service;

import com.nivi.pojo.Product;

import java.util.List;

/**
 * @Author: pxp167
 * @Date: 9/28/2018
 *
 */
public interface ProductService {

  void save(Product product);

  List<Product> getProducts();

}
