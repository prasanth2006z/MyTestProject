package com.nivi.pojo;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

/**
 * @Author: pxp167
 * @Date: 9/26/2018
 *
 */
@Entity
@Table(name="Order")
public class Order {
  private static final long serialVersionUID = 1L;
  @Id
  @GeneratedValue(strategy= GenerationType.AUTO)
  @Column(name="Order_ID")
  private int orderID;
  @Column(name="Order_Status")
  private String orderStatus;
  @Column(name="Delivery_Status")
  private String deliveryStatus;
  //@OneToOne(cascade = CascadeType.ALL)
  private User user;
  //@OneToMany(cascade = CascadeType.ALL)
  private List<Product> products;
  @Column(name="Feed_Back")
  private String feedBack;
  @Column(name="Order_Date")
  private Date orderDate;

  public int getOrderID() {
    return orderID;
  }

  public void setOrderID(int orderID) {
    this.orderID = orderID;
  }

  public String getOrderStatus() {
    return orderStatus;
  }

  public void setOrderStatus(String orderStatus) {
    this.orderStatus = orderStatus;
  }

  public String getDeliveryStatus() {
    return deliveryStatus;
  }

  public void setDeliveryStatus(String deliveryStatus) {
    this.deliveryStatus = deliveryStatus;
  }

  public User getUser() {
    return user;
  }

  public void setUser(User user) {
    this.user = user;
  }

  public List<Product> getProducts() {
    return products;
  }

  public void setProducts(List<Product> products) {
    this.products = products;
  }

  public Date getOrderDate() {
    return orderDate;
  }

  public void setOrderDate(Date orderDate) {
    this.orderDate = orderDate;
  }

  public String getFeedBack() {
    return feedBack;
  }

  public void setFeedBack(String feedBack) {
    this.feedBack = feedBack;
  }
}
