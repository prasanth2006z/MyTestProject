package com.nivi.pojo;

/**
 * @Author: pxp167
 * @Date: 9/26/2018
 *
 */

public class RepoBalance {
  private long balanceId;
  private long itemId;
  private long balance;

  public long getBalanceId() {
    return balanceId;
  }

  public void setBalanceId(long balanceId) {
    this.balanceId = balanceId;
  }

  public long getItemId() {
    return itemId;
  }

  public void setItemId(long itemId) {
    this.itemId = itemId;
  }

  public long getBalance() {
    return balance;
  }

  public void setBalance(long balance) {
    this.balance = balance;
  }
}
