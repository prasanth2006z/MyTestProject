package com.nivi.constants;

/**
 * @Author: pxp167
 * @Date: 9/26/2018
 *
 */
public class Constant {

  public static final String DATE_FORMAT="yyyy.MM.dd  HH:mm:ss z";
  public static final int MINIMUM_WATER_REPO_BALANCE=50;
}
